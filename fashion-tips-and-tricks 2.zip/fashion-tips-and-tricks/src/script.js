function getIcon(category) {
  switch(category) {
    case 'Men': return '🧥';
    case 'Women': return '👗';
    case 'Accessories': return '👜';
    case 'Seasonal': return '🍂';
    default: return '✨';
  }
}

tip.textContent = `${getIcon(tip.category)} ${tip.text} (${tip.category})`;
const tips = [
  {
    text: "Layer your outfits for dimension and versatility.",
    category: "Men",
    image: "https://images.unsplash.com/photo-1521334884684-d80222895322?auto=format&fit=crop&w=400&q=60"
  },
  {
    text: "Invest in quality basics – they never go out of style.",
    category: "Women",
    image: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=400&q=60"
  },
  {
    text: "Add a statement piece like a bold necklace or watch.",
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&w=400&q=60"
  },
  {
    text: "Switch to breathable fabrics in summer like cotton or linen.",
    category: "Seasonal",
    image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=60"
  },
  {
    text: "Always match your belt with your shoes for a polished look.",
    category: "Men",
    image: "https://images.unsplash.com/photo-1520975690377-9ed8c1b83302?auto=format&fit=crop&w=400&q=60"
  },
  {
    text: "Scarves are perfect to spice up a simple outfit.",
    category: "Accessories",
    image: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=400&q=60"
  },
  {
    text: "Monochrome outfits can look chic and elongate your silhouette.",
    category: "Women",
    image: "https://images.unsplash.com/photo-1521334884684-d80222895322?auto=format&fit=crop&w=400&q=60"
  },
  {
    text: "Layer sweaters over shirts for a cozy fall look.",
    category: "Seasonal",
    image: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=400&q=60"
  }
];
function renderTips(filter = 'all') {
  tipsContainer.innerHTML = '';
  const filtered = tips.filter(tip => filter === 'all' || tip.category === filter);
  if (filtered.length === 0) {
    tipsContainer.innerHTML = '<p>No tips found for this category.</p>';
    return;
  }
  filtered.forEach(tip => {
    const card = document.createElement('div');
    card.className = 'tip-card';

    const img = document.createElement('img');
    img.src = tip.image;
    img.alt = tip.text;
    img.className = 'tip-image';

    const text = document.createElement('p');
    text.textContent = `${tip.text} (${tip.category})`;

    card.appendChild(img);
    card.appendChild(text);
    tipsContainer.appendChild(card);
  });
}
function showRandomTip() {
  const filter = categoryFilter.value;
  const filtered = tips.filter(tip => filter === 'all' || tip.category === filter);
  if (filtered.length === 0) {
    tipsContainer.innerHTML = '<p>No tips found to show.</p>';
    return;
  }
  const randomTip = filtered[Math.floor(Math.random() * filtered.length)];
  tipsContainer.innerHTML = `
    <div class="tip-card">
      <img src="${randomTip.image}" alt="${randomTip.text}" class="tip-image" />
      <p>${randomTip.text} (${randomTip.category})</p>
    </div>
  `;
}
function showRandomTip() {
  const filter = categoryFilter.value;
  const filtered = tips.filter(tip => filter === 'all' || tip.category === filter);
  if (filtered.length === 0) {
    tipsContainer.innerHTML = '<p>No tips found to show.</p>';
    return;
  }
  const randomTip = filtered[Math.floor(Math.random() * filtered.length)];
  tipsContainer.innerHTML = `
    <div class="tip-card">
      <img src="${randomTip.image}" alt="${randomTip.text}" class="tip-image" />
      <p>${randomTip.text} (${randomTip.category})</p>
    </div>
  `;
}
function showDailyTip() {
  const index = new Date().getDate() % tips.length;
  const tip = tips[index];
  document.getElementById('dailyTipText').textContent = `${tip.text} (${tip.category})`;
}
showDailyTip();
{
  text: "...",
  category: "...",
  image: "...",
  shop: "https://example.com/fashion-product"
}
const btn = document.createElement('a');
btn.href = tip.shop;
btn.target = "_blank";
btn.textContent = "🛍️ Shop the Look";
btn.className = "shop-btn";
card.appendChild(btn);
const celebrityStyles = [
  {
    name: "Zendaya",
    img: "https://images.unsplash.com/photo-1600047507160-17d5f1bcca52?fit=crop&w=400&q=60",
    style: "Effortless glam and red-carpet chic."
  },
  {
    name: "Harry Styles",
    img: "https://images.unsplash.com/photo-1626808642879-b3f024a1f3a1?fit=crop&w=400&q=60",
    style: "Vintage flair with modern edge."
  },
  {
    name: "Rihanna",
    img: "https://images.unsplash.com/photo-1622443469067-0b826155a8d9?fit=crop&w=400&q=60",
    style: "Fearless, bold, and trend-defying."
  },
  {
    name: "Timothée Chalamet",
    img: "https://images.unsplash.com/photo-1589578527966-c7e6dc1f3f10?fit=crop&w=400&q=60",
    style: "High-fashion meets everyday cool."
  },
  {
    name: "Hailey Bieber",
    img: "https://images.unsplash.com/photo-1544723795-3fb6469f5b39?fit=crop&w=400&q=60",
    style: "Minimalist streetwear elegance."
  }
];

function renderCelebrityStyle() {
  const container = document.querySelector('.celebrity-gallery');
  celebrityStyles.forEach(celeb => {
    const card = document.createElement('div');
    card.className = 'celebrity-card';
    card.innerHTML = `
      <img src="${celeb.img}" alt="${celeb.name}">
      <div class="info">
        <h4>${celeb.name}</h4>
        <p>${celeb.style}</p>
      </div>
    `;
    container.appendChild(card);
  });
}
renderCelebrityStyle();
